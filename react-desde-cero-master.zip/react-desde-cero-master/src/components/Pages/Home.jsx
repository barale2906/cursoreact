import React from "react"
import Banner from "../Organisms/Banner";

const Home = () => (
    <Banner />
)

export default Home